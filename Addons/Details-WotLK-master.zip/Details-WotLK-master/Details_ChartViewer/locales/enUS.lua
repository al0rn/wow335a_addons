local L = LibStub("AceLocale-3.0"):NewLocale("Details_ChartViewer", "enUS", true)
if not L then return end

L["STRING_ADDEDOKAY"] = "Successfully added."
L["STRING_CONFIRM"] = "Confirm"
L["STRING_NEWTAB"] = "New Tab"
L["STRING_OPTIONS"] = "Chart Viewer Options"
L["STRING_OPTIONS_SHOWICON"] = "Show Icon"
L["STRING_OPTIONS_WINDOWSCALE"] = "Window Scale"
L["STRING_PLUGIN_DESC"] = "View data collected by Details! on simple line charts."
L["STRING_PLUGIN_NAME"] = "Chart Viewer"
L["STRING_TOOLTIP"] = "Open Chart Viewer"
L["STRING_TOOSHORTNAME"] = "The name is too short."

