local AceLocale = LibStub:GetLibrary("AceLocale-3.0")
local L = AceLocale:NewLocale("GearScore", "enUS", true)
if not L then return end

	L["Human"] = true
	L["Dwarf"] = true
	L["Gnome"] = true
	L["BloodElf"] = true
	L["NightElf"] = true
	L["Orc"] = true
	L["Tauren"] = true
	L["Troll"] = true
	L["Draenei"] = true
	L["Undead"] = true
	L["Warrior"] = true
	L["Death Knight"] = true
	L["Paladin"] = true
	L["Shaman"] = true
	L["Hunter"] = true
	L["Druid"] = true
	L["Rogue"] = true
	L["Warlock"] = true
	L["Priest"] = true
	L["Mage"] = true
