local select, UnitBuff, UnitDebuff, UnitAura, tonumber, strfind, hooksecurefunc =
	select, UnitBuff, UnitDebuff, UnitAura, tonumber, strfind, hooksecurefunc

local function addLine(self,id,isItem)
	if isItem then
		self:AddDoubleLine("ItemID:","|cffffffff"..id)
	else
		self:AddDoubleLine("SpellID:","|cffffffff"..id)
	end
	self:Show()
end

-- Spell Hooks ----------------------------------------------------------------
hooksecurefunc(GameTooltip, "SetUnitBuff", function(self,...)
	local id = select(11,UnitBuff(...))
	if id then addLine(self,id) end
end)

hooksecurefunc(GameTooltip, "SetUnitDebuff", function(self,...)
	local id = select(11,UnitDebuff(...))
	if id then addLine(self,id) end
end)

hooksecurefunc(GameTooltip, "SetUnitAura", function(self,...)
	local id = select(11,UnitAura(...))
	if id then addLine(self,id) end
end)

GameTooltip:HookScript("OnTooltipSetSpell", function(self)
	local id = select(3,self:GetSpell())
	if id then addLine(self,id) end
end)

-- Item Hooks -----------------------------------------------------------------
hooksecurefunc("SetItemRef", function(link, ...)
	local id = tonumber(link:match("spell:(%d+)"))
	if id then addLine(ItemRefTooltip,id) end
end)

local function attachItemTooltip(self)
	local link = select(2,self:GetItem())
	if not link then return end
	local id = select(3,strfind(link, "^|%x+|Hitem:(%-?%d+):(%d+):(%d+):(%d+):(%d+):(%d+):(%-?%d+):(%-?%d+)"))
	if id then addLine(self,id,true) end
end

GameTooltip:HookScript("OnTooltipSetItem", attachItemTooltip)
ItemRefTooltip:HookScript("OnTooltipSetItem", attachItemTooltip)
ItemRefShoppingTooltip1:HookScript("OnTooltipSetItem", attachItemTooltip)
ItemRefShoppingTooltip2:HookScript("OnTooltipSetItem", attachItemTooltip)
ItemRefShoppingTooltip3:HookScript("OnTooltipSetItem", attachItemTooltip)
ShoppingTooltip1:HookScript("OnTooltipSetItem", attachItemTooltip)
ShoppingTooltip2:HookScript("OnTooltipSetItem", attachItemTooltip)
ShoppingTooltip3:HookScript("OnTooltipSetItem", attachItemTooltip)

---- NPC Hooks ----------------------------------------------------------------
--local function idnps(npsID, ...)
--    local sName, iUnit = npsID:GetUnit()
--    local isPlayer = UnitIsPlayer("mouseover")
--    if (iUnit == "mouseover") then
--        if isPlayer == nil then
--            npsID:AddLine("ID: " .. tonumber(string.sub(UnitGUID("mouseover"), 9, 12), 16))
--        end
--    end
--end
--GameTooltip:HookScript("OnTooltipSetUnit", idnps)
--
---- Player Hooks ----------------------------------------------------------------
--local function GUIDPlayer(PlayerGUID, ...)
--    local sName, iUnit = PlayerGUID:GetUnit()
--    local isPlayer = UnitIsPlayer("mouseover")
--    if (iUnit == "mouseover") then
--        if isPlayer == 1 then
--            PlayerGUID:AddLine("GUID: " .. tonumber(string.sub(UnitGUID("mouseover"), 9, 18), 16))
--        end
--    end
--end
--GameTooltip:HookScript("OnTooltipSetUnit", GUIDPlayer)  

---- NPC Hooks ---- Player Hooks ----
local function F() 
	local g=GameTooltip;
	if g:IsShown() then 
	local d=UnitGUID("mouseover")
	local B = tonumber(d:sub(5,5), 16) % 8;
	local C = tonumber(d:sub(6,12), 16);
	local D = tonumber(d:sub(9,12), 16);
	local E = tonumber(d:sub(13,18), 16);
	if B==0 then g:AddLine("GUID: "..E);
	end;
	if B==4 then g:AddLine("PET: "..C);
	end;
	if B==3 then g:AddLine("NPC: "..D);g:AddLine("Spawn: "..E);
	end;
--	g:AppendText(" - "..d);
	g:AppendText("  ");
	end;
	end;
	local f=CreateFrame("frame");f:RegisterEvent("UPDATE_MOUSEOVER_UNIT");f:SetScript("OnEvent",F)

-- Quest Hooks ----------------------------------------------------------------
local QuestLevel_original_GetQuestLogTitle = GetQuestLogTitle; 
function GetQuestLogTitle(questIndex) 
  questTitle, level, questTag, suggestedGroup, isHeader, isCollapsed, isComplete, isDaily, questID = QuestLevel_original_GetQuestLogTitle(questIndex) 
  if (questTitle and (not isHeader)) then 
   --questTitle = "["..questID.."] ".. questTitle 
   questTitle = questTitle .." ["..questID.."] "
  end 
  return questTitle, level, questTag, suggestedGroup, isHeader, isCollapsed, isComplete, isDaily, questID 
end

hooksecurefunc("SetItemRef", function(link, ...) 
      local id = tonumber(link:match(":(%d+)")) 
      if (id) then   
    ItemRefTooltip:AddDoubleLine("ID: " .. id); 
    ItemRefTooltip:Show(); 
   end 
end)

