RangeColors by Yarko
--------------------

A World of Warcraft add-on that provides more obvious action button coloring for out of mana/rage/energy and out of range conditions.

Configure colors through the RangeColors interface options panel.
