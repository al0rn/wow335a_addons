
RANGECOLORS_TITLE = "RangeColors";

RANGECOLORS_CONFIG_HEADERINFO = "Sets the color of action bar buttons to indicate target out of range or "
	.."low on mana, energy or rage.";

RANGECOLORS_CONFIG_RANGECOLOR = "Out-of-range color";
RANGECOLORS_CONFIG_MANACOLOR = "Low-on-mana color";

