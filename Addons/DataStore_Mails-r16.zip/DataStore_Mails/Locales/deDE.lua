local L = LibStub("AceLocale-3.0"):NewLocale( "DataStore_Mails", "deDE" )

if not L then return end

L["Mail Expiry Warning"] = "Mail Ablauf Warnung"
L["Scan mail body (marks it as read)"] = "Inhalt der Briefe scannen (markiert als gelesen)"
L["Warn when mail expires in less days than this value"] = "Warnen, wenn Post abläuft in weniger Tagen als"

