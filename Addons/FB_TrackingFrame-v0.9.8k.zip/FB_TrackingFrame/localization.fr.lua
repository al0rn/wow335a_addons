FB_TFTranslations["frFR"] = {
   TRACKING_INFO = "Affiche les donn\195\169es sur les poissons";
   TRACKING = "Archives";

   BINDING_NAME_TOGGLEFISHINGBUDDY_TRK = "Toggle: #NAME# (Panneau de donn\195\169es)";
};

FB_TFTranslations["frFR"].TRACKING_HELP = {
      "|c#GREEN#/fb #TRACKING#|r",
      "    Un mauvais affichage du moment de prise d'un poisson surveill\195\169",
};

FB_TFTranslations["frFR"].TRACK_HELP = {
      "|c#GREEN#/fb #TRACK#|r [|c#GREEN##HOURLY#|r or |c#GREEN##WEEKLY#|r] |c#PURPLE#<fish link>|r",
      "    Surveille le temps de prise pour ce poisson (Maj-Click)",
};

FB_TFTranslations["frFR"].NOTRACK_HELP = {
      "|c#GREEN#/fb #NOTRACK#|r |c#PURPLE#<fish link>|r",
      "    Retire ce poisson (Maj-Click) du surveillant",
};
