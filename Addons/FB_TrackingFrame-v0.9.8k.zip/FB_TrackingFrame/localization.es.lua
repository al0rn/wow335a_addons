FB_TFTranslations["esES"] = {
   TRACKING_INFO = "Muestra #NAME# informaci\195\179on de pesca ciclica",
   TRACKING_TAB = "Seguimiento",

   TRACK = "sigue",
   NOTRACK = "no siguas",
   TRACKING = "siguiendo",

   TRACKINGMSG = "Segumiento '%s' %s.",
   NOTRACKERRMSG = "No puede borrar pesca ciclica.",
   NOTRACKMSG = "Pesca ciclica borrada '%s'.",
};
