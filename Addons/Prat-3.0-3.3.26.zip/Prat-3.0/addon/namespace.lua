--[[
Name: Prat 3.0 (namespace.lua)
Revision: $Revision: 79586 $
Author(s): Sylvaanar (sylvanaar@mindspring.com)
Inspired By: Prat 2.0, Prat, and idChat2 by Industrial
Website: http://files.wowace.com/Prat/
Documentation: http://www.wowace.com/wiki/Prat
Forum: http://www.wowace.com/forums/index.php?topic=6243.0
SVN: http://svn.wowace.com/wowace/trunk/Prat/
Description: Defines the addon namespace(s)
]]

Prat = Prat or {}

SVC_NAMESPACE = Prat