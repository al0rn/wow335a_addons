﻿local L = LibStub("AceLocale-3.0"):NewLocale("DataStore", "enUS", true, true)

if not L then return end

L["Enabled"] = true
L["Disabled"] = true
L["Memory used for %d |4character:characters;:"] = true
